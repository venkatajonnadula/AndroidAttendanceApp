package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class ClasslistAdapter extends RecyclerView.Adapter<ClasslistAdapter.MyViewHolder> {

    Context context;
    ArrayList<StudentsTable> students;
    String attendanceStatus;

    public ClasslistAdapter(Context context, ArrayList<StudentsTable> students) {
        this.context = context;
        this.students = students;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.attendance_single_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {


        StudentsTable student = students.get(position);

        holder.studentNameTextView.setText(student.getStudentName());


    }

    @Override
    public int getItemCount() {
        return students.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView studentNameTextView;
        LinearLayout classlistLinearLayout;
        RadioButton radioButtonPresent;
        RadioButton radioButtonAbsent;
        RadioButton radioButtonLate;
        RadioGroup radioGroupButtons;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            studentNameTextView = itemView.findViewById(R.id.studentNameTextView);
            classlistLinearLayout = itemView.findViewById(R.id.classlistLinearLayout);
            radioButtonPresent = itemView.findViewById(R.id.radioButtonPresent);
            radioButtonAbsent = itemView.findViewById(R.id.radioButtonAbsent);
            radioButtonLate = itemView.findViewById(R.id.radioButtonLate);
            radioGroupButtons = itemView.findViewById(R.id.radioGroupButtons);


        }







    }


}
