package com.example.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    //Professors Table
    public static final String PROFESSORS_TABLE = "PROFESSORS";
    public static final String COLUMN_PROFESSOR_ID = "Professor_ID";
    public static final String COLUMN_NAME = "Name";


    //Login Table
    public static final String LOGIN_TABLE = "LOGIN";
    public static final String USERNAME = "Username";
    public static final String PASSWORD = "Password";

    //Courses Table
    public static final String COURSES_TABLE = "COURSES";
    public static final String COLUMN_COURSE_ID = "Course_ID";
    public static final String COLUMN_COURSE_NAME = "Course_Name";
    public static final String COLUMN_CAMPUS = "Campus";


    //Students Table
    public static final String STUDENTS_TABLE = "STUDENTS";
    public static final String COLUMN_STUDENT_ID = "Student_ID";
    public static final String COLUMN_STUDENT_NAME = "Student_Name";


    //Attendance Table
    public static final String ATTENDANCE_TABLE = "ATTENDANCE";
    public static final String COLUMN_DATE = "Date";
    public static final String COLUMN_ATTENDANCE_STATUS = "Attendance_Status";


    //Enrollment Table
    public static final String ENROLLMENT_TABLE = "ENROLLMENT";
    public static final String COLUMN_ENROLLMENT_ID = "Enrollment_ID";





    public DatabaseHelper(@Nullable Context context) {
        super(context, "attendance.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Professors Table
        String createProfessorsTable = "CREATE TABLE " + PROFESSORS_TABLE + " ( " + COLUMN_PROFESSOR_ID + " INTEGER PRIMARY KEY, " + COLUMN_NAME + " VARCHAR);";
        db.execSQL(createProfessorsTable);

        //Login Table
        String createLoginTable = "CREATE TABLE " + LOGIN_TABLE + " ( " + COLUMN_PROFESSOR_ID + " INTEGER PRIMARY KEY, " + USERNAME + " VARCHAR, " + PASSWORD + " VARCHAR);";
        db.execSQL(createLoginTable);


        //Courses Table
        String createCoursesTable = "CREATE TABLE " + COURSES_TABLE + " ( " + COLUMN_COURSE_ID + " VARCHAR PRIMARY KEY, " + COLUMN_COURSE_NAME + " VARCHAR, " + COLUMN_PROFESSOR_ID + " INTEGER, " + COLUMN_CAMPUS + " VARCHAR, FOREIGN KEY (" + COLUMN_PROFESSOR_ID + ") REFERENCES " + PROFESSORS_TABLE + ");";
        db.execSQL(createCoursesTable);

        //Students Table
        String createStudentsTable = "CREATE TABLE " + STUDENTS_TABLE + " ( " + COLUMN_STUDENT_ID + " VARCHAR PRIMARY KEY, " + COLUMN_STUDENT_NAME + " VARCHAR, " + COLUMN_CAMPUS + " VARCHAR, FOREIGN KEY (" + COLUMN_CAMPUS + ") REFERENCES " + COURSES_TABLE + ");";
        db.execSQL(createStudentsTable);

        //Attendance Table
        String createAttendanceTable = "CREATE TABLE " + ATTENDANCE_TABLE + " ( " + COLUMN_STUDENT_ID + " VARCHAR, " + COLUMN_COURSE_ID + " VARCHAR, " + COLUMN_DATE + " DATE, " + COLUMN_ATTENDANCE_STATUS + " VARCHAR, FOREIGN KEY (" + COLUMN_STUDENT_ID + ") REFERENCES " + STUDENTS_TABLE +  ", FOREIGN KEY (" + COLUMN_COURSE_ID + ") REFERENCES " + COURSES_TABLE  + ");";
        db.execSQL(createAttendanceTable);


        //Enrollments Table
        String createEnrollmentTable = "CREATE TABLE " + ENROLLMENT_TABLE + " ( " + COLUMN_ENROLLMENT_ID + " INTEGER PRIMARY KEY, " + COLUMN_COURSE_ID + " VARCHAR, " + COLUMN_STUDENT_ID + " VARCHAR, FOREIGN KEY (" + COLUMN_STUDENT_ID + ") REFERENCES " + STUDENTS_TABLE +  ", FOREIGN KEY (" + COLUMN_COURSE_ID + ") REFERENCES " + COURSES_TABLE  + ");";
        db.execSQL(createEnrollmentTable);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {


    }

    public void addData() {
        SQLiteDatabase db = this.getWritableDatabase();


        //professors table
        ContentValues venkata = new ContentValues();
        ContentValues hasan = new ContentValues();

        venkata.put(COLUMN_PROFESSOR_ID, 1);
        venkata.put(COLUMN_NAME, "Venkata");

        hasan.put(COLUMN_PROFESSOR_ID, 2);
        hasan.put(COLUMN_NAME, "Hasan");


        //Login Table
        ContentValues venkataLogin = new ContentValues();
        ContentValues hasanLogin = new ContentValues();

        venkataLogin.put(COLUMN_PROFESSOR_ID, 1);
        venkataLogin.put(USERNAME, "venkata");
        venkataLogin.put(PASSWORD, "venkata");

        hasanLogin.put(COLUMN_PROFESSOR_ID, 2);
        hasanLogin.put(USERNAME, "hasan");
        hasanLogin.put(PASSWORD, "hasan");


        //Courses Table
        ContentValues math = new ContentValues();
        ContentValues programming = new ContentValues();
        ContentValues statistics = new ContentValues();
        ContentValues english = new ContentValues();
        ContentValues networking = new ContentValues();
        ContentValues linux = new ContentValues();


        math.put(COLUMN_COURSE_ID, "MTH234");
        math.put(COLUMN_COURSE_NAME, "Math");
        math.put(COLUMN_PROFESSOR_ID, "1");
        math.put(COLUMN_CAMPUS, "A");

        programming.put(COLUMN_COURSE_ID, "COM855");
        programming.put(COLUMN_COURSE_NAME, "Programming");
        programming.put(COLUMN_PROFESSOR_ID, "1");
        programming.put(COLUMN_CAMPUS, "B");

        statistics.put(COLUMN_COURSE_ID, "STA139");
        statistics.put(COLUMN_COURSE_NAME, "Statistics");
        statistics.put(COLUMN_PROFESSOR_ID, "2");
        statistics.put(COLUMN_CAMPUS, "A");

        english.put(COLUMN_COURSE_ID, "ENG785");
        english.put(COLUMN_COURSE_NAME, "English");
        english.put(COLUMN_PROFESSOR_ID, "2");
        english.put(COLUMN_CAMPUS, "B");

        networking.put(COLUMN_COURSE_ID, "NET452");
        networking.put(COLUMN_COURSE_NAME, "Networking");
        networking.put(COLUMN_PROFESSOR_ID, "2");
        networking.put(COLUMN_CAMPUS, "B");

        linux.put(COLUMN_COURSE_ID, "LIN756");
        linux.put(COLUMN_COURSE_NAME, "Linux");
        linux.put(COLUMN_PROFESSOR_ID, "1");
        linux.put(COLUMN_CAMPUS, "A");




        //Students Table
        ContentValues bob = new ContentValues();
        ContentValues tommy = new ContentValues();
        ContentValues sarah = new ContentValues();
        ContentValues lisa = new ContentValues();
        ContentValues amber = new ContentValues();
        ContentValues tyler = new ContentValues();

        bob.put(COLUMN_STUDENT_ID, "443");
        bob.put(COLUMN_STUDENT_NAME, "Bob");
        bob.put(COLUMN_CAMPUS, "A");

        tommy.put(COLUMN_STUDENT_ID, "140");
        tommy.put(COLUMN_STUDENT_NAME, "Tommy");
        tommy.put(COLUMN_CAMPUS, "A");

        sarah.put(COLUMN_STUDENT_ID, "532");
        sarah.put(COLUMN_STUDENT_NAME, "Sarah");
        sarah.put(COLUMN_CAMPUS, "B");

        lisa.put(COLUMN_STUDENT_ID, "778");
        lisa.put(COLUMN_STUDENT_NAME, "Lisa");
        lisa.put(COLUMN_CAMPUS, "B");

        amber.put(COLUMN_STUDENT_ID, "983");
        amber.put(COLUMN_STUDENT_NAME,"Amber");
        amber.put(COLUMN_CAMPUS, "A");

        tyler.put(COLUMN_STUDENT_ID, "399");
        tyler.put(COLUMN_STUDENT_NAME, "Tyler");
        tyler.put(COLUMN_CAMPUS, "B");


        //Attendance Table


        //Enrollments Table
        ContentValues mth1 = new ContentValues();
        ContentValues mth2 = new ContentValues();
        ContentValues mth3 = new ContentValues();

        ContentValues com1 = new ContentValues();
        ContentValues com2 = new ContentValues();
        ContentValues com3 = new ContentValues();

        ContentValues sta1 = new ContentValues();
        ContentValues sta2 = new ContentValues();
        ContentValues sta3 = new ContentValues();

        ContentValues eng1 = new ContentValues();
        ContentValues eng2 = new ContentValues();
        ContentValues eng3 = new ContentValues();

        ContentValues net1 = new ContentValues();
        ContentValues net2 = new ContentValues();
        ContentValues net3 = new ContentValues();

        ContentValues lin1 = new ContentValues();
        ContentValues lin2 = new ContentValues();
        ContentValues lin3 = new ContentValues();

        mth1.put(COLUMN_COURSE_ID, "MTH234");
        mth1.put(COLUMN_STUDENT_ID, "443");

        mth2.put(COLUMN_COURSE_ID, "MTH234");
        mth2.put(COLUMN_STUDENT_ID, "140");

        mth3.put(COLUMN_COURSE_ID, "MTH234");
        mth3.put(COLUMN_STUDENT_ID, "983");

        com1.put(COLUMN_COURSE_ID, "COM855");
        com1.put(COLUMN_STUDENT_ID, "532");

        com2.put(COLUMN_COURSE_ID, "COM855");
        com2.put(COLUMN_STUDENT_ID, "778");

        com3.put(COLUMN_COURSE_ID, "COM855");
        com3.put(COLUMN_STUDENT_ID, "399");

        sta1.put(COLUMN_COURSE_ID, "STA139");
        sta1.put(COLUMN_STUDENT_ID, "443");

        sta2.put(COLUMN_COURSE_ID, "STA139");
        sta2.put(COLUMN_STUDENT_ID, "140");

        sta3.put(COLUMN_COURSE_ID, "STA139");
        sta3.put(COLUMN_STUDENT_ID, "983");


        eng1.put(COLUMN_COURSE_ID, "ENG785");
        eng1.put(COLUMN_STUDENT_ID, "532");

        eng2.put(COLUMN_COURSE_ID, "ENG785");
        eng2.put(COLUMN_STUDENT_ID, "778");

        eng3.put(COLUMN_COURSE_ID, "ENG785");
        eng3.put(COLUMN_STUDENT_ID, "399");

        net1.put(COLUMN_COURSE_ID, "NET452");
        net1.put(COLUMN_STUDENT_ID, "532");

        net2.put(COLUMN_COURSE_ID, "NET452");
        net2.put(COLUMN_STUDENT_ID, "778");

        net3.put(COLUMN_COURSE_ID, "NET452");
        net3.put(COLUMN_STUDENT_ID, "399");

        lin1.put(COLUMN_COURSE_ID, "LIN756");
        lin1.put(COLUMN_STUDENT_ID, "443");

        lin2.put(COLUMN_COURSE_ID, "LIN756");
        lin2.put(COLUMN_STUDENT_ID, "140");

        lin3.put(COLUMN_COURSE_ID, "LIN756");
        lin3.put(COLUMN_STUDENT_ID, "983");




        db.insert(PROFESSORS_TABLE, null, venkata);
        db.insert(PROFESSORS_TABLE, null, hasan);


        db.insert(LOGIN_TABLE, null, venkataLogin);
        db.insert(LOGIN_TABLE, null, hasanLogin);


        db.insert(COURSES_TABLE, null, math);
        db.insert(COURSES_TABLE, null, programming);
        db.insert(COURSES_TABLE, null, statistics);
        db.insert(COURSES_TABLE, null, english);
        db.insert(COURSES_TABLE, null, networking);
        db.insert(COURSES_TABLE, null, linux);


        db.insert(STUDENTS_TABLE, null, bob);
        db.insert(STUDENTS_TABLE, null, tommy);
        db.insert(STUDENTS_TABLE, null, sarah);
        db.insert(STUDENTS_TABLE, null, lisa);
        db.insert(STUDENTS_TABLE, null, amber);
        db.insert(STUDENTS_TABLE, null, tyler);

        db.insert(ENROLLMENT_TABLE, null, mth1);
        db.insert(ENROLLMENT_TABLE, null, mth2);
        db.insert(ENROLLMENT_TABLE, null, mth3);

        db.insert(ENROLLMENT_TABLE, null, com1);
        db.insert(ENROLLMENT_TABLE, null, com2);
        db.insert(ENROLLMENT_TABLE, null, com3);

        db.insert(ENROLLMENT_TABLE, null, sta1);
        db.insert(ENROLLMENT_TABLE, null, sta2);
        db.insert(ENROLLMENT_TABLE, null, sta3);

        db.insert(ENROLLMENT_TABLE, null, eng1);
        db.insert(ENROLLMENT_TABLE, null, eng2);
        db.insert(ENROLLMENT_TABLE, null, eng3);

        db.insert(ENROLLMENT_TABLE, null, net1);
        db.insert(ENROLLMENT_TABLE, null, net2);
        db.insert(ENROLLMENT_TABLE, null, net3);

        db.insert(ENROLLMENT_TABLE, null, lin1);
        db.insert(ENROLLMENT_TABLE, null, lin2);
        db.insert(ENROLLMENT_TABLE, null, lin3);





    }


    public String[] getLoginCredentials() {
        SQLiteDatabase db = this.getReadableDatabase();


        String getVenkataUsername = "SELECT USERNAME FROM LOGIN WHERE USERNAME = 'venkata';";
        Cursor cursorVenkataUsername = db.rawQuery(getVenkataUsername, null);
        cursorVenkataUsername.moveToFirst();
        String venkataUsername = cursorVenkataUsername.getString(0);
        cursorVenkataUsername.close();

        String getVenkataPassword = "SELECT PASSWORD FROM LOGIN WHERE PASSWORD = 'venkata';";
        Cursor cursorVenkataPassword = db.rawQuery(getVenkataPassword, null);
        cursorVenkataPassword.moveToFirst();
        String venkataPassword = cursorVenkataPassword.getString(0);
        cursorVenkataPassword.close();

        String getHasanUsername = "SELECT USERNAME FROM LOGIN WHERE USERNAME = 'hasan';";
        Cursor cursorHasanUsername = db.rawQuery(getHasanUsername, null);
        cursorHasanUsername.moveToFirst();
        String hasanUsername = cursorHasanUsername.getString(0);
        cursorHasanUsername.close();

        String getHasanPassword = "SELECT PASSWORD FROM LOGIN WHERE PASSWORD = 'hasan';";
        Cursor cursorHasanPassword = db.rawQuery(getHasanPassword, null);
        cursorHasanPassword.moveToFirst();
        String hasanPassword = cursorHasanPassword.getString(0);
        cursorHasanPassword.close();

        //String[] credentials = new String[];
        return new String[]{venkataUsername, venkataPassword, hasanUsername, hasanPassword};


    }


    public ArrayList<CoursesTable> getCourses(String username) {


        ArrayList<CoursesTable> courses = new ArrayList<>();

        String getCourses = "SELECT c.* FROM " + COURSES_TABLE + " c, " + LOGIN_TABLE + " l WHERE l." + USERNAME + "='" + username + "'" + " AND l." + COLUMN_PROFESSOR_ID + "= c." + COLUMN_PROFESSOR_ID;


        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(getCourses, null);


        cursor.moveToFirst();
        while(!cursor.isAfterLast()){


            String courseID = cursor.getString(0);
            String courseName = cursor.getString(1);
            String professorID = cursor.getString(2);
            String campus = cursor.getString(3);

            CoursesTable course = new CoursesTable(courseID, courseName, professorID, campus);
            courses.add(course);

            cursor.moveToNext();

        }



        cursor.close();
        db.close();
        return courses;


    }

    public ArrayList<CoursesTable> getCoursesLocation(String username, String location) {


        ArrayList<CoursesTable> courses = new ArrayList<>();

        String getCourses = "SELECT c.* FROM " + COURSES_TABLE + " c, " + LOGIN_TABLE + " l WHERE l." + USERNAME + "='" + username + "'" + " AND l." + COLUMN_PROFESSOR_ID + "= c." + COLUMN_PROFESSOR_ID + " AND c." + COLUMN_CAMPUS + " = '" + location + "';";


        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(getCourses, null);


        cursor.moveToFirst();
        while(!cursor.isAfterLast()){


            String courseID = cursor.getString(0);
            String courseName = cursor.getString(1);
            String professorID = cursor.getString(2);
            String campus = cursor.getString(3);

            CoursesTable course = new CoursesTable(courseID, courseName, professorID, campus);
            courses.add(course);

            cursor.moveToNext();

        }



        cursor.close();
        db.close();
        return courses;


    }



    public ArrayList<StudentsTable> getClasslist(String courseId){


        ArrayList<StudentsTable> students = new ArrayList<>();

        String getStudents = "SELECT s.* FROM " + STUDENTS_TABLE + " s, " + ENROLLMENT_TABLE + " e WHERE s." + COLUMN_STUDENT_ID + "= e." + COLUMN_STUDENT_ID + " AND e." + COLUMN_COURSE_ID + "=" + "'" + courseId + "' " + "GROUP BY s." + COLUMN_STUDENT_ID + ", s." + COLUMN_STUDENT_NAME + " ORDER BY s." + COLUMN_STUDENT_NAME + ";";


        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(getStudents, null);


        cursor.moveToFirst();
        while(!cursor.isAfterLast()){

            int studentId = cursor.getInt(0);
            String studentName = cursor.getString(1);
            String campus = cursor.getString(2);

            StudentsTable student = new StudentsTable(studentId, studentName, campus);
            students.add(student);

            cursor.moveToNext();

        }



        cursor.close();
        db.close();
        return students;


    }

    public void saveAttendance(String attendanceStatus, String studentName, String date, String courseName){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues attendanceEntry = new ContentValues();




        String getStudentId = "SELECT " + COLUMN_STUDENT_ID + " FROM " + STUDENTS_TABLE + " WHERE " + COLUMN_STUDENT_NAME + " = " + "'" + studentName + "'";

        String getCourseId = "SELECT " + COLUMN_COURSE_ID + " FROM " + COURSES_TABLE + " WHERE " + COLUMN_COURSE_NAME + " = " + "'" + courseName + "'";


        SQLiteDatabase dbRead = this.getReadableDatabase();

        Cursor cursorStudentId = db.rawQuery(getStudentId, null);
        cursorStudentId.moveToFirst();
        String studentId = cursorStudentId.getString(0);
        cursorStudentId.close();


        Cursor cursorCourseId = db.rawQuery(getCourseId, null);
        cursorCourseId.moveToFirst();
        String courseId = cursorCourseId.getString(0);
        cursorCourseId.close();


        attendanceEntry.put(COLUMN_STUDENT_ID, studentId);
        attendanceEntry.put(COLUMN_COURSE_ID, courseId);
        attendanceEntry.put(COLUMN_DATE, date);
        attendanceEntry.put(COLUMN_ATTENDANCE_STATUS, attendanceStatus);

        db.insert(ATTENDANCE_TABLE, null, attendanceEntry);


    }


}
