package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    Context context;
    ArrayList<CoursesTable> courses;

    public CustomAdapter(Context context, ArrayList<CoursesTable> courses) {
        this.context = context;
        this.courses = courses;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.course_items, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {


        CoursesTable course = courses.get(position);

        holder.courseNameTextView.setText(course.getCourse_name());

        holder.courseListLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, Classlist.class);
                intent.putExtra("courseName", course.getCourse_name());
                intent.putExtra("courseId", course.getCourse_id());
                context.startActivity(intent);


            }
        });





    }

    @Override
    public int getItemCount() {
        return courses.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView courseNameTextView;
        LinearLayout courseListLinearLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            courseNameTextView = itemView.findViewById(R.id.courseNameTextView);
            courseListLinearLayout = itemView.findViewById(R.id.courseListLinearLayout);


        }



    }


}
