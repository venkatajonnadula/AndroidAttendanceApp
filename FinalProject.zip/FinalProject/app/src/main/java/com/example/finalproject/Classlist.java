package com.example.finalproject;

import static android.webkit.ConsoleMessage.MessageLevel.LOG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

public class Classlist extends AppCompatActivity {


    RecyclerView recyclerView;
    TextView classlistCourseNameTextView;
    ClasslistAdapter classlistAdapter;
    Button saveButton;
    TextView textViewDate;


    String date;

    String attendanceStatus;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classlist);

        String courseId = getIntent().getStringExtra("courseId");
        String courseName = getIntent().getStringExtra("courseName");
        classlistCourseNameTextView = findViewById(R.id.classlistCourseNameTextView);
        saveButton = findViewById(R.id.saveButton);
        textViewDate = findViewById(R.id.textViewDate);
        classlistCourseNameTextView.setText(courseName);


        DatabaseHelper databaseHelper = new DatabaseHelper(Classlist.this);


        recyclerView = findViewById(R.id.classListRecyclerView);


        ArrayList<StudentsTable> students = databaseHelper.getClasslist(courseId);

        classlistAdapter = new ClasslistAdapter(Classlist.this, students);



        recyclerView.setAdapter(classlistAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(Classlist.this));



        textViewDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                ConstraintLayout classList = (ConstraintLayout) findViewById(R.id.classListMainConstraintLayout);

                LayoutInflater inflater = getLayoutInflater();
                View calendarLayout = inflater.inflate(R.layout.calendar, classList, false);

                //calendarLayout.setBackgroundColor(Color.parseColor("#FFFFFF"));

                classList.addView(calendarLayout);

                CalendarView calendarView1 = (CalendarView) findViewById(R.id.calendarView1);
                calendarView1.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                    @Override
                    public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth)
                    {
                        String month1 = null;
                        String day = null;
                        if (month==0|| month==1 || month==2 || month==3 || month==4 || month==5 || month==6 || month==7 || month==8){
                            month1 = "0" + (month + 1);
                        }

                        else{
                            month1 = String.valueOf(month + 1);
                        }

                        if (dayOfMonth==1|| dayOfMonth==2 || dayOfMonth==3 || dayOfMonth==4 || dayOfMonth==5 || dayOfMonth==6 || dayOfMonth==7 || dayOfMonth==8 || dayOfMonth==9){
                            day = "0" + dayOfMonth;
                        }
                        else{
                            day = String.valueOf(dayOfMonth);
                        }

                        date = year + "-" + month1 + "-" + day;
                        classList.removeView(calendarLayout);
                        textViewDate.setText(date);
                    }
                });



            }
        });




        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                for (int i = 0; i < recyclerView.getChildCount(); i++){

                    RecyclerView.ViewHolder holder = recyclerView.findViewHolderForAdapterPosition(i);

                    RadioGroup radioGroupButtons = holder.itemView.findViewById(R.id.radioGroupButtons);

                    int radioButtoncheckedID = radioGroupButtons.getCheckedRadioButtonId();

                    switch(radioButtoncheckedID){

                        case R.id.radioButtonPresent:
                            attendanceStatus = "Present";
                            break;

                        case R.id.radioButtonAbsent:
                            attendanceStatus = "Absent";
                            break;

                        case R.id.radioButtonLate:
                            attendanceStatus = "Late";
                            break;

                        default:
                            attendanceStatus = null;
                            break;

                    }


                    TextView studentNameTextView = holder.itemView.findViewById(R.id.studentNameTextView);
                    String studentName = studentNameTextView.getText().toString();
                    String courseName = classlistCourseNameTextView.getText().toString();


                    DatabaseHelper databaseHelper = new DatabaseHelper(Classlist.this);

                    databaseHelper.saveAttendance(attendanceStatus, studentName, date, courseName);

                    Toast.makeText(getBaseContext(), "Saved!", Toast.LENGTH_SHORT).show();


                }



            }
        });







    }






}