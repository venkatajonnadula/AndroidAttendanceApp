package com.example.finalproject;

public class StudentsTable {


    private int studentId;
    private String studentName;
    private String campus;


    public StudentsTable(int studentId, String studentName, String campus) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.campus = campus;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }

    @Override
    public String toString() {
        return "StudentsTable{" +
                "studentId=" + studentId +
                ", studentName='" + studentName + '\'' +
                ", campus='" + campus + '\'' +
                '}';
    }
}
