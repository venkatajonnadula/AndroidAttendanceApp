package com.example.finalproject;

public class CoursesTable {

    public String course_id;
    public String course_name;
    public String professor_id;
    public String campus;


    public CoursesTable(String course_id, String course_name, String professor_id, String campus) {
        this.course_id = course_id;
        this.course_name = course_name;
        this.professor_id = professor_id;
        this.campus = campus;

    }

    public String getCourse_id() {
        return course_id;
    }

    public void setCourse_id(String course_id) {
        this.course_id = course_id;
    }

    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }

    public String getProfessor_id() {
        return professor_id;
    }

    public void setProfessor_id(String professor_id) {
        this.professor_id = professor_id;
    }

    @Override
    public String toString() {
        return "CoursesTable{" +
                "course_id='" + course_id + '\'' +
                ", course_name='" + course_name + '\'' +
                ", professor_id='" + professor_id + '\'' +
                ", campus='" + campus + '\'' +
                '}';
    }
}
