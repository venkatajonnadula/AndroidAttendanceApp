package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.location.Location;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class Courses extends AppCompatActivity {


    RecyclerView recyclerView;
    CustomAdapter customAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.courses);

        ArrayList<CoursesTable> courses = null;

        String username = getIntent().getStringExtra("username");
        Double latitude = getIntent().getDoubleExtra("latitude",0);
        Double longitude = getIntent().getDoubleExtra("longitude", 0);

        latitude = Math.round(latitude * 100.0)/100.0;
        longitude = Math.round(longitude * 100.0)/100.0;

        DatabaseHelper databaseHelper = new DatabaseHelper(Courses.this);


        recyclerView = findViewById(R.id.coursesRecyclerView);


        if (((latitude != 43.77 && latitude != 43.78 && latitude != 43.79) && (longitude != -79.21 && longitude != -79.22 && longitude != -79.23)) && ((latitude != 43.77 && latitude != 43.78 && latitude != 43.79) && (longitude != -79.18 && longitude != -79.19 && longitude != -79.20 ))){

            courses = databaseHelper.getCourses(username);

        }

        else{

            if ((latitude == 43.77 || latitude == 43.78 || latitude == 43.79) && (longitude == -79.21 || longitude == -79.22 || longitude == -79.23)){

                String location = "A";
                courses = databaseHelper.getCoursesLocation(username, location);

            }

            else if ((latitude == 43.77 || latitude == 43.78 || latitude == 43.79) && (longitude == -79.18 || longitude == -79.19 || longitude == -79.20 )){

                String location = "B";
                courses = databaseHelper.getCoursesLocation(username, location);

            }


        }





        customAdapter = new CustomAdapter(Courses.this, courses);

        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(Courses.this));


    }
}